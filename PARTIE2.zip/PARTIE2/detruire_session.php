<?php
    // Démarre ou restaure la session
    session_start();

    // Détruit toutes les variables de session
    session_destroy();

    // Redirige vers une autre page
    header('Location: index.php');
    exit;
?>