<?php
class Person {
    public $nom;
    public $prenom;

    
    public function getFullName() {
        return $this->nom . ' <br>'  . $this->prenom. ' <br>';
    }
    
    public function getDescription() {
        return "Je m'appelle " . $this->getFullName();
    }
}

$person1 = new Person();
$person1->nom = "RAKOTONINDRNA";
$person1->prenom= "Chrsitian Mizael";


$person2 = new Person();
$person2->nom = "VOAHARIMPITIAVANA";
$person2->prenom= "Andraina Faniriana";


echo $person1->getDescription() . ' <br>';
echo $person2->getDescription() ;
?>