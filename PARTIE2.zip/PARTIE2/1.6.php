<?php

    if (isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['sexe']) && isset($_POST['vins'])) {
      $nom = $_POST['nom'];
      $prenom = $_POST['prenom'];
      $sexe = $_POST['sexe'];
      $villes = $_POST['vins'];

      echo "Nom: " . $nom . "<br>";
      echo "Prénom: " . $prenom . "<br>";
      echo "Sexe: " . $sexe . "<br>";
      echo "Villes: ";
      foreach($villes as $ville) {
        echo $ville . ", ";
      }
    } else {
      echo "Veuillez remplir tous les champs du formulaire.";
    }

?>