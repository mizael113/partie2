<?php
class Personne {
    public $nom;
    public $prenom;

    public function presenter() {
        return "Je m'appelle " . $this->nom . " " . $this->prenom;
    }
}

// EXEMPLE
$personne = new Personne();
$personne->nom = "RAKOTONINDRINA";
$personne->prenom = "Chrsitian Mizael";

echo $personne->presenter(); 


?>