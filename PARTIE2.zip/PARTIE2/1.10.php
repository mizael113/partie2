<?php
class Person {
    private $dateDeNaissance;

    public function __construct($dateDeNaissance) {
        $this->dateDeNaissance = $dateDeNaissance;
    }

    public function getDateDeNaissance() {
        return $this->dateDeNaissance;
    }

    public function getAge() {
        $dateActuelle = new DateTime();
        $dateNaissance = new DateTime($this->dateDeNaissance);
        $difference = $dateActuelle->diff($dateNaissance);
        return $difference->y;
    }
}

// Exemple d'utilisation
$personne = new Person("2006-09-11");
$dateDeNaissance = $personne->getDateDeNaissance();
$age = $personne->getAge();

echo "Date de naissance: " . $dateDeNaissance . "<br>";
echo "Âge: " . $age . " ans";
?>