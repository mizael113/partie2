<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['texte'])) {
    $texte = $_POST['texte'];
    $texteAvecBr = nl2br($texte);
    echo $texteAvecBr;
  } else {
    echo "Veuillez saisir du texte s'il vous plait.";
  }
}
?>