<?php
    // Démarre ou restaure la session
    session_start();

    // Vérifie si le formulaire a été soumis
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Récupère les valeurs du formulaire
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];

        // Stocke les valeurs dans des variables de session
        $_SESSION['nom'] = $nom;
        $_SESSION['prenom'] = $prenom;

        // Redirige vers une autre page ou affiche un message de confirmation
        header('Location: confirmation.php');
        exit;
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Ouvrir une session</title>
</head>
<body>
    <h1>Ouvrir une session</h1>

    <form method="POST" action="">
        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom" required><br><br>

        <label for="prenom">Prénom :</label>
        <input type="text" id="prenom" name="prenom" required><br><br>

        <input type="submit" value="Envoyer">
    </form>
</body>
</html>