<?php
$date = date('d/m/Y'); 
$heure = date('H');

if ($heure >= 0 && $heure < 12) {
    $message = "Bon matin";
} elseif ($heure >= 12 && $heure < 18) {
    $message = "Bonne après-midi";
}

echo "Nous sommes le " . $date . ". " . $message;
?>