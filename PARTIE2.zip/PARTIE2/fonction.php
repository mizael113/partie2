<?php

function verif($pseudo, $motdepasse) {
   
    $bdd = new PDO('mysql:host=localhost;dbname=Banque;charset=utf8', 'root', '');
    $requete = $bdd->prepare('SELECT * FROM membres WHERE pseudo = ? AND motdepasse = ?');
    $requete->execute([$pseudo, $motdepasse]);

return $requete->rowCount() > 0;
}
?>