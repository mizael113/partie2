<?php
include 'fonctions.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $pseudo = $_POST['pseudo'];
    $motdepasse = $_POST['motdepasse'];


    $resultat = verif($pseudo, $motdepasse);


    if ($resultat) {
    
        header("Location: page_privee.php");
        exit();
    } else {
        
        echo "Identifiants incorrects. Veuillez réessayer.";
    }
}
?>