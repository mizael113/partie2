<?php

    session_start();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];

    
        $_SESSION['nom'] = $nom;
        $_SESSION['prenom'] = $prenom;

    
        if (isset($_SESSION['compteur'])) {
            $_SESSION['compteur']++;
        } else {
            $_SESSION['compteur'] = 1;
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Créer une session</title>
</head>
<body>
    <h1>Créer une session</h1>

    <?php
    
        if (isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
            echo "<p>Nom : " . $_SESSION['nom'] . "</p>";
            echo "<p>Prénom : " . $_SESSION['prenom'] . "</p>";
            echo "<p>Nombre de vues : " . $_SESSION['compteur'] . "</p>";
        } else {
            echo "<p>Aucune variable de session n'a été définie.</p>";
        }
    ?>

    <a href="menu.html">Retourner au menu</a>
</body>
</html>