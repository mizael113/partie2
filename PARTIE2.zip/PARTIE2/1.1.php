<?php
$date = date('j/m/Y'); 
echo "Hello PHP, nous sommes le " . $date;
?>